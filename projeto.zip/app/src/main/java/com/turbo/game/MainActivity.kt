package com.turbo.game

import android.app.Activity
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray

class MainActivity : Activity() {
    inner class Bridge {
        @JavascriptInterface
        fun games(): String {
            val pm = packageManager
            val out = JSONArray()
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
                .filter { it.packageName != packageName && ((it.flags and ApplicationInfo.FLAG_IS_GAME) != 0 || it.category == ApplicationInfo.CATEGORY_GAME) }
                .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
                .forEach { out.put(JSONArray().put(pm.getApplicationLabel(it).toString()).put(it.packageName)) }
            return out.toString()
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.addJavascriptInterface(Bridge(), "TG")
        w.loadUrl("file:///android_asset/index.html")
        setContentView(w)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { moveTaskToBack(true) }
}
