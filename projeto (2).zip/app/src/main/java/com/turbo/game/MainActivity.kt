package com.turbo.game

import android.app.Activity
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private fun open(a: String, u: String?) {
        val i = Intent(a)
        if (u != null) i.data = Uri.parse(u)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runOnUiThread { startActivity(i) }
    }

    inner class Bridge {
        @JavascriptInterface
        fun games(): String {
            val pm = packageManager
            val out = JSONArray()
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
                .filter { it.packageName != packageName && ((it.flags and ApplicationInfo.FLAG_IS_GAME) != 0 || it.category == ApplicationInfo.CATEGORY_GAME) }
                .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
                .forEach { out.put(JSONArray().put(pm.getApplicationLabel(it).toString()).put(it.packageName)) }
            return out.toString()
        }

        @JavascriptInterface
        fun stats(): String = Sys.stats(this@MainActivity).toString()

        @JavascriptInterface
        fun cleanRam(): String = JSONObject().put("mb", Sys.cleanRam(this@MainActivity)).toString()

        @JavascriptInterface
        fun root(): String = Sh.hasRoot().toString()

        @JavascriptInterface
        fun copy(t: String): String {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            runOnUiThread { cm.setPrimaryClip(ClipData.newPlainText("codigo", t)) }
            return "true"
        }

        @JavascriptInterface
        fun runCode(id: String): String {
            val c = when (id) {
                "anim" -> "settings put global window_animation_scale 0.5; settings put global transition_animation_scale 0.5; settings put global animator_duration_scale 0.5"
                "anim0" -> "settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0"
                "kill" -> "am kill-all"
                "trim" -> "pm trim-caches 999999999999"
                "dex" -> "cmd package compile -m speed-profile -a"
                "bg" -> "cmd package bg-dexopt-job"
                "idle" -> "sm idle-maint run"
                else -> return "{\"ok\":false}"
            }
            if (!Sh.hasRoot()) return "{\"ok\":false,\"need\":\"root\"}"
            Thread { Sh.run(c) }.start()
            return "{\"ok\":true}"
        }

        @JavascriptInterface
        fun cleanOwn(): String {
            var n = 0L
            for (d in listOf(cacheDir, externalCacheDir)) {
                if (d != null) {
                    for (f in d.walkTopDown()) if (f.isFile) n += f.length()
                    d.listFiles()?.forEach { it.deleteRecursively() }
                }
            }
            return JSONObject().put("mb", n / 1048576).toString()
        }

        @JavascriptInterface
        fun clearCache(pkg: String): String {
            if (Sh.hasRoot()) {
                Sh.run("rm -rf /data/data/$pkg/cache/* /data/data/$pkg/code_cache/* /sdcard/Android/data/$pkg/cache/*")
                return "{\"ok\":true}"
            }
            open(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, "package:$pkg")
            return "{\"ok\":false}"
        }

        @JavascriptInterface
        fun launch(pkg: String, name: String, opts: String): String {
            val o = JSONObject(opts)
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, "package:$packageName")
                return "{\"ok\":false,\"need\":\"overlay\"}"
            }
            val nm = getSystemService(NotificationManager::class.java)
            if (o.optBoolean("dnd") && !nm.isNotificationPolicyAccessGranted) {
                open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, null)
                return "{\"ok\":false,\"need\":\"dnd\"}"
            }
            val li = packageManager.getLaunchIntentForPackage(pkg) ?: return "{\"ok\":false,\"need\":\"nolaunch\"}"
            if (o.optBoolean("ram")) Sys.cleanRam(this@MainActivity)
            if (Sh.hasRoot()) {
                Thread {
                    if (o.optBoolean("perf")) Sh.run("cmd game mode performance $pkg")
                    if (o.optBoolean("anim")) Sh.run("settings put global animator_duration_scale 0.5; settings put global transition_animation_scale 0.5; settings put global window_animation_scale 0.5")
                    if (o.optBoolean("comp")) Sh.run("cmd package compile -m speed-profile -f $pkg")
                }.start()
            }
            if (o.optBoolean("ov", true)) {
                val s = Intent(this@MainActivity, OverlayService::class.java)
                    .putExtra("pkg", pkg)
                    .putExtra("name", name)
                    .putExtra("awake", o.optBoolean("awake"))
                    .putExtra("dnd", o.optBoolean("dnd"))
                    .putExtra("heat", o.optInt("heat", 0))
                startForegroundService(s)
            }
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runOnUiThread { startActivity(li) }
            return "{\"ok\":true}"
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.addJavascriptInterface(Bridge(), "TG")
        w.loadUrl("file:///android_asset/index.html")
        setContentView(w)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        moveTaskToBack(true)
    }
}
