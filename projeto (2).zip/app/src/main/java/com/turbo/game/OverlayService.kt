package com.turbo.game

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import org.json.JSONObject

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var box: LinearLayout? = null
    private var info: TextView? = null
    private var dot: GradientDrawable? = null
    private val h = Handler(Looper.getMainLooper())
    private val ex = Executors.newSingleThreadExecutor()
    private var pkg = ""
    private var name = ""
    private var heat = 0
    private var fps = "FPS real: verificando..."
    private var layer: String? = null
    private var prevFilter = -1
    private var running = true
    private var last: JSONObject? = null

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            render(Sys.stats(this@OverlayService))
            ex.execute { readFps() }
            h.postDelayed(this, 1500)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        pkg = i?.getStringExtra("pkg") ?: ""
        name = i?.getStringExtra("name") ?: ""
        heat = i?.getIntExtra("heat", 0) ?: 0
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("tg", "Turbo Game", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "tg").setContentTitle("Turbo Game ativo").setSmallIcon(android.R.drawable.ic_dialog_info).build())
        if (box == null) build(i?.getBooleanExtra("awake", false) == true)
        if (i?.getBooleanExtra("dnd", false) == true && nm.isNotificationPolicyAccessGranted) {
            prevFilter = nm.currentInterruptionFilter
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        }
        h.removeCallbacks(tick)
        h.post(tick)
        return START_NOT_STICKY
    }

    private fun button(t: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { f() }
        return b
    }

    private fun build(awake: Boolean) {
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        val bubble = TextView(this)
        bubble.text = "⚡"
        bubble.textSize = 22f
        bubble.gravity = Gravity.CENTER
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        d.setColor(0xFFFFB547.toInt())
        dot = d
        bubble.background = d
        b.addView(bubble, LinearLayout.LayoutParams(dp(46), dp(46)))
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(12), dp(10), dp(12), dp(10))
        val pd = GradientDrawable()
        pd.setColor(0xEE201D40.toInt())
        pd.cornerRadius = dp(14).toFloat()
        panel.background = pd
        panel.visibility = View.GONE
        val t = TextView(this)
        t.setTextColor(0xFFF1EFFF.toInt())
        t.textSize = 13f
        t.minWidth = dp(210)
        info = t
        panel.addView(t)
        panel.addView(button("Limpar RAM agora") {
            ex.execute {
                val mb = Sys.cleanRam(this@OverlayService)
                h.post { Toast.makeText(this@OverlayService, "$mb MB liberados", Toast.LENGTH_SHORT).show() }
            }
        })
        panel.addView(button("Fechar ícone") { stopSelf() })
        b.addView(panel)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or (if (awake) WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON else 0),
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = dp(140)
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x
                    sy = lp.y
                    tx = e.rawX
                    ty = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    lp.x = sx + dx.toInt()
                    lp.y = sy + dy.toInt()
                    w.updateViewLayout(b, lp)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        panel.visibility = if (panel.visibility == View.GONE) View.VISIBLE else View.GONE
                    }
                }
            }
            true
        }
        w.addView(b, lp)
        box = b
        ex.execute {
            if (!Sh.hasRoot()) {
                fps = "FPS real: precisa de root"
                h.post { render(null) }
            }
        }
    }

    private fun readFps() {
        if (!Sh.hasRoot()) return
        var l = layer
        if (l == null) {
            val names = (Sh.run("dumpsys SurfaceFlinger --list") ?: "").lines().map { it.trim() }.filter { it.contains(pkg) }
            l = names.firstOrNull { it.contains("SurfaceView") && it.contains("BLAST") }
                ?: names.firstOrNull { it.contains("SurfaceView") }
                ?: names.firstOrNull()
        }
        if (l == null) {
            fps = "FPS real: aguardando o jogo"
            return
        }
        layer = l
        val out = Sh.run("dumpsys SurfaceFlinger --latency '$l'") ?: return
        val ts = out.lines().drop(1)
            .mapNotNull { it.trim().split(Regex("\\s+")).getOrNull(1)?.toLongOrNull() }
            .filter { it > 0 && it < Long.MAX_VALUE / 2 }
        if (ts.size < 2) {
            layer = null
            return
        }
        val sec = (ts.last() - ts.first()) / 1e9
        if (sec > 0) fps = "FPS real: " + Math.round((ts.size - 1) / sec)
    }

    private fun render(s: JSONObject?) {
        if (s != null) last = s
        val j = last ?: return
        val temp = j.optDouble("temp")
        val hot = heat > 0 && temp >= heat
        dot?.setColor(if (hot) 0xFFFF6B86.toInt() else 0xFFFFB547.toInt())
        val warn = if (hot) "\n⚠ Quente! Limite de $heat °C" else ""
        info?.text = name + "\n" + fps + "\nRAM em uso: " + j.optInt("ram") + "% · livre " + j.optInt("free") + " MB\nTemperatura: " + temp + " °C\nBateria: " + j.optInt("bat") + "%" + warn
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacks(tick)
        try {
            box?.let { wm?.removeView(it) }
        } catch (e: Exception) {
        }
        if (prevFilter != -1) getSystemService(NotificationManager::class.java).setInterruptionFilter(prevFilter)
        ex.shutdown()
        super.onDestroy()
    }
}
