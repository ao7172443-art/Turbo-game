package com.turbo.game

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import org.json.JSONObject

object Sh {
    private var rooted: Boolean? = null

    fun run(cmd: String): String? = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Exception) {
        null
    }

    fun hasRoot(): Boolean {
        val c = rooted
        if (c != null) return c
        val r = run("id")?.contains("uid=0") == true
        rooted = r
        return r
    }
}

object Sys {
    fun stats(c: Context): JSONObject {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val b: Intent? = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val t = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        var th = 0
        if (Build.VERSION.SDK_INT >= 29) {
            th = (c.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus
        }
        return JSONObject()
            .put("ram", (100 * (mi.totalMem - mi.availMem) / mi.totalMem).toInt())
            .put("free", (mi.availMem / 1048576).toInt())
            .put("temp", t)
            .put("bat", 100 * lvl / sc)
            .put("th", th)
    }

    fun cleanRam(c: Context): Long {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val before = mi.availMem
        for (a in c.packageManager.getInstalledApplications(0)) {
            if (a.packageName != c.packageName) am.killBackgroundProcesses(a.packageName)
        }
        Thread.sleep(1200)
        am.getMemoryInfo(mi)
        return maxOf(0L, (mi.availMem - before) / 1048576)
    }
}
